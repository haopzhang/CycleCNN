#! /usr/bin/python
# -*- coding: utf8 -*-

import tensorflow as tf
import tensorlayer as tl
from tensorlayer.layers import *

def cycle_g1(t_image, is_train=False, reuse=False):
    # network g1
    w_init = tf.random_normal_initializer(stddev=0.02)
    b_init = tf.constant_initializer(value=0.0)
    g_init = tf.random_normal_initializer(1., 0.02)
    b, h ,w ,c = t_image.shape 
    with tf.variable_scope("cycle_g1", reuse=reuse) as vs:
        tl.layers.set_name_reuse(reuse)
        n = InputLayer(t_image, name='in')
        n = Conv2d(n, 64, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init,name='n64s1/c')
        temp = n

        # B residual blocks
        for i in range(16):
            nn = Conv2d(n, 64, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init, name='n64s1/c1/%s' % i)
            nn = Conv2d(nn, 64, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n64s1/c2/%s' % i)
            nn.outputs = nn.outputs * 0.1
            nn = ElementwiseLayer([n, nn], tf.add, 'b_residual_add/%s' % i)
            n = nn

        n = Conv2d(n, 64, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n64s1/c/m')
        n = ElementwiseLayer([n, temp], tf.add, 'add3')
        # B residual blacks end

        n = Conv2d(n, 256, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n256s1/1')
        n = SubpixelConv2d(n, scale=2, n_out_channel=None, act=tf.nn.relu, name='pixelshufflerx2/1')

        n = Conv2d(n, 256, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n256s1/2')
        n = SubpixelConv2d(n, scale=2, n_out_channel=None, act=tf.nn.relu, name='pixelshufflerx2/2')

        n = Conv2d(n, c, (1, 1), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='out')
        n.outputs = tf.clip_by_value(n.outputs, 0.0, 255.0)
        return n

def cycle_g2(t_image, is_train=False, reuse=False):
    # network g2
    w_init = tf.random_normal_initializer(stddev = 0.02)
    b_init = tf.constant_initializer(value = 0.0)
    g_init = tf.random_normal_initializer(1., 0.02)
    b, h, w, c = t_image.shape
    with tf.variable_scope("cycle_g2", reuse=reuse) as vs:
        tl.layers.set_name_reuse(reuse)
        n = InputLayer(t_image, name='in')
        n = Conv2d(n, 32, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/s1')

        n = meanpool2d(n, filter_size=(2, 2), strides=(2, 2), padding='SAME', name='pool1')
        n = Conv2d(n, 32, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/s2')

        n = meanpool2d(n, filter_size=(2, 2), strides=(2, 2), padding='SAME', name='pool2')
        n = Conv2d(n, 32, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/s3')
        temp=n
        # B residual blocks
        for i in range(5):
            nn = Conv2d(n, 32, (3, 3), (1, 1), act=tf.nn.relu, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/c1/%s' % i)
            nn = Conv2d(nn, 32, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/c2/%s' % i)
            nn.outputs = nn.outputs * 0.1
            nn = ElementwiseLayer([n, nn], tf.add, 'b_residual_add/%s' % i)
            n = nn

        n = Conv2d(n, 32, (3, 3), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='n32s1/c/m')
        n = ElementwiseLayer([n, temp], tf.add, 'add3')
        # B residual blacks end

        n = Conv2d(n, c, (1, 1), (1, 1), act=None, padding='SAME', W_init=w_init, b_init=b_init, name='out')
        n.outputs = tf.clip_by_value(n.outputs, 0.0, 255.0)
        return n


def cycle_network_test(low_height_test, low_width_test, channels_test, test_batch_low, sess):

    x = tf.placeholder("float", [low_height_test , low_width_test,channels_test], name="input") 
    x_image = tf.reshape(x, [1,low_height_test, low_width_test, channels_test])
    output_image = cycle_g1(x_image, False, True)
    out_image = sess.run(output_image.outputs, feed_dict={x: test_batch_low})

    return out_image


def cycle2_network_test(high_height_test, high_width_test, channels_test, test_batch_high, sess):

    x = tf.placeholder("float", [high_height_test, high_width_test, channels_test], name="input")
    x_image = tf.reshape(x, [1, high_height_test, high_width_test, channels_test])
    output_image = cycle_g2(x_image, False, True)
    out_image = sess.run(output_image.outputs, feed_dict={x: test_batch_high})

    return out_image

