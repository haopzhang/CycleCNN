# Non-pairwise-trained Cycle Convolutional Neural Network for Single Remote Sensing Image Super-Resolution

LR -> cycle_g1 -> HR
HR -> cycle_g2 -> LR

## Project Structure
`main.py`   train and test cycle_cnn model
`model.py`  the network structure of cycle_cnn
`config.py` the hyperparameter of cycle_cnn
`testdata`  the testdata of our experiments
...

## Run Code
Environment: python3
Package requirement is in `requirement.txt`


