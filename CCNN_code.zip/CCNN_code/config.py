from easydict import EasyDict as edict
import json

config = edict()
config.TRAIN = edict()

## Adam
config.TRAIN.batch_size = 8
config.TRAIN.lr_init = 1e-4
config.TRAIN.beta1 = 0.9
config.TRAIN.n_epoch_init = 2000
config.TRAIN.decay_every = int(config.TRAIN.n_epoch_init // 2)
config.TRAIN.lr_decay = 0.1
config.TRAIN.channels = 3
config.TRAIN.hr_height = 1024
config.TRAIN.hr_width = 1024

config.TRAIN.hr_img_path = 'data/train_hr'
config.TRAIN.lr_img_path = 'data/train_lr'

config.VALID = edict()
config.VALID.hr_img_path = 'data/valid_hr'
config.VALID.lr_img_path = 'data/valid_lr'

config.TEST = edict()
config.TEST.hr_img_path = 'data/test_hr/'
config.TEST.lr_img_path = 'data/test_lr'





def log_config(filename, cfg):
    with open(filename, 'w') as f:
        f.write("================================================\n")
        f.write(json.dumps(cfg, indent=4))
        f.write("\n================================================\n")
