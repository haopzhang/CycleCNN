import tensorflow as tf

sess = tf.InteractiveSession()  # 定义进程
norm=tf.Variable(initial=tf.n)

def _PS(X, r, n_out_channel):
    if n_out_channel > 1:
        assert int(X.get_shape()[-1]) == (r ** 2) * n_out_channel, _err_log
        X = tf.transpose(X, [0, 2, 1, 3])
        X = tf.depth_to_space(X, r)
        X = tf.transpose(X, [0, 2, 1, 3])
    else:
        print(_err_log)
    return X