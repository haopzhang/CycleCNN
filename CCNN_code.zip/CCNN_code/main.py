#! /usr/bin/python
# -*- coding: utf8 -*-

import os, time, pickle, random, time
from datetime import datetime
import numpy as np
from time import localtime, strftime
import logging, scipy

import tensorflow as tf
import tensorlayer as tl
from model import *
from utils import *
from config import config, log_config
from index import *

###====================== HYPER-PARAMETERS ===========================###
batch_size = config.TRAIN.batch_size
lr_init = config.TRAIN.lr_init
beta1 = config.TRAIN.beta1
n_epoch_init = config.TRAIN.n_epoch_init
lr_decay = config.TRAIN.lr_decay
decay_every = config.TRAIN.decay_every
hr_height = config.TRAIN.hr_height
hr_width = config.TRAIN.hr_width
channels = config.TRAIN.channels

def train():

    ## create folders to save result images and trained model
    save_dir_ginit = "samples/{}_ginit".format(tl.global_flag['mode'])
    tl.files.exists_or_mkdir(save_dir_ginit)
    checkpoint_dir = "checkpoint_cyclecnn"  # checkpoint model name
    tl.files.exists_or_mkdir(checkpoint_dir)

    ###====================== PRE-LOAD DATA ===========================###
    train_hr_img_list = sorted(tl.files.load_file_list(path=config.TRAIN.hr_img_path, regx='.*.[png][jpg]', printable=False))
    train_lr_img_list = sorted(tl.files.load_file_list(path=config.TRAIN.lr_img_path, regx='.*.[png][jpg]', printable=False))
    train_hr_imgs = tl.vis.read_images(train_hr_img_list, path=config.TRAIN.hr_img_path, n_threads=32)
    train_lr_imgs = tl.vis.read_images(train_lr_img_list, path=config.TRAIN.lr_img_path, n_threads=32)

    # valid_hr_img_list = sorted(tl.files.load_file_list(path=config.VALID.hr_img_path, regx='.*.[png][jpg]', printable=False))
    # valid_lr_img_list = sorted(tl.files.load_file_list(path=config.VALID.lr_img_path, regx='.*.[png][jpg]', printable=False))
    # valid_hr_imgs = tl.vis.read_images(valid_hr_img_list, path=config.VALID.hr_img_path, n_threads=32)
    # valid_lr_imgs = tl.vis.read_images(valid_lr_img_list, path=config.VALID.lr_img_path, n_threads=32)

    test_hr_img_list = sorted(tl.files.load_file_list(path=config.TEST.hr_img_path, regx='.*.[png][jpg]', printable=False))
    test_lr_img_list = sorted(tl.files.load_file_list(path=config.TEST.lr_img_path, regx='.*.[png][jpg]', printable=False))
    test_hr_imgs = tl.vis.read_images(test_hr_img_list, path=config.TEST.hr_img_path, n_threads=1)
    test_lr_imgs = tl.vis.read_images(test_lr_img_list, path=config.TEST.lr_img_path, n_threads=1)

    ###========================== DEFINE MODEL ============================###
    t_image = tf.placeholder('float32', [None, 96, 96, channels], name='t_image_input_to_generator')
    t_bic_image = tf.placeholder('float32', [None, 96, 96, channels], name='bic_from_highimage')
    t_target_image = tf.placeholder('float32', [None, 384, 384, channels], name='t_target_image')

    net_g1 = cycle_g1(t_image, is_train=True, reuse=False)
    net_g2 = cycle_g2(net_g1.outputs, is_train=True, reuse=False)
    net_g2_r = cycle_g2(t_target_image, is_train=True, reuse=True)
    net_g1_r = cycle_g1(net_g2_r.outputs, is_train=True, reuse=True)
    net_idt = cycle_g1(t_bic_image, is_train=True, reuse=True)
    net_g1.print_params(False)
    net_g2.print_params(False)
    net_g1_test = cycle_g1(t_image, is_train=False, reuse=True)
    net_g2_test = cycle_g2(net_g1_test.outputs, is_train=False, reuse=True)


    ###========================== DEFINE LOSS ============================###
    mse_loss = tl.cost.mean_squared_error(net_g2.outputs, t_image, is_mean=True)
    mse_loss_r = tl.cost.mean_squared_error(net_g1_r.outputs, t_target_image, is_mean=True)
    idt_loss = tl.cost.mean_squared_error(net_idt.outputs, t_target_image, is_mean=True)
    g1_loss = mse_loss_r + mse_loss + idt_loss
    g2_loss = mse_loss + mse_loss_r
    g1_vars = tl.layers.get_variables_with_name('cycle_g1', True, True)
    g2_vars = tl.layers.get_variables_with_name('cycle_g2', True, True)

    with tf.variable_scope('learning_rate'):
        lr_v = tf.Variable(lr_init, trainable=False)
    ## Train
    g_optim  = tf.train.AdamOptimizer(lr_v, beta1=beta1).minimize(g2_loss + g1_loss, var_list = g2_vars + g1_vars)

    ###========================== RESTORE MODEL =============================###
    sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=False))
    tl.layers.initialize_global_variables(sess)
    # if tl.files.load_and_assign_npz(sess=sess, name=checkpoint_dir + '/g_{}.npz'.format(tl.global_flag['mode']),
    #                                 network=net_g1) is False:
    #     tl.files.load_and_assign_npz(sess=sess,
    #                                  name=checkpoint_dir + '/g1_{}_init_490.npz'.format(tl.global_flag['mode']),
    #                                  network=net_g1)
    #     tl.files.load_and_assign_npz(sess=sess,srgan
    #                                  name=checkpoint_dir + '/g2_{}_init_490.npz'.format(tl.global_flag['mode']),
    #                                  network=net_g2)

    sess.run(tf.assign(lr_v, lr_init))
    total_ssim=[]
    total_psnr=[]
    mse_total=[]
    mser_total=[]
    idt_total=[]
    print(" ** fixed learning rate: %f (for init G)" % lr_init)
    test_psnr = []
    test_ssim = []
    test_bic_ssim = []
    test_bic_psnr = []

    for epoch in range(n_epoch_init):

        if epoch == decay_every:
            sess.run(tf.assign(lr_v, lr_init * config.TRAIN.lr_decay))
            log = " ** new learning rate: %f (for SR)" % (lr_init * config.TRAIN.lr_decay)
            print(log)
        epoch_time = time.time()
        total_mse_loss, total_idt_loss, n_iter, total_mse_r = 0, 0, 0, 0
        for idx in range(0, len(train_hr_imgs)//batch_size*batch_size, batch_size):
            step_time = time.time()
            h_offset_low = int(np.random.uniform(0, hr_height//4 - 96 - 1))
            w_offset_low = int(np.random.uniform(0, hr_width//4 - 96 - 1))
            h_offset_high = 4 * h_offset_low
            w_offset_high = 4 * w_offset_low
            b_imgs_384 = tl.prepro.threading_data(train_hr_imgs[idx:idx + batch_size], fn=crop_xy_high, h=h_offset_high, w=w_offset_high, is_random=False)
            b_imgs_low = tl.prepro.threading_data(train_lr_imgs[idx:idx + batch_size], fn=crop_xy_low, h=h_offset_low, w=w_offset_low, is_random=False)
            # b_imgs_384 = tl.prepro.threading_data(train_hr_imgs[idx:idx + batch_size], fn=crop_sub_imgs_fn, is_random=True)
            # b_imgs_low = tl.prepro.threading_data(train_lr_imgs[idx:idx + batch_size], fn=crop_sub_imgs_fn_96, is_random=True)
            b_imgs_low_p = b_imgs_low.reshape([batch_size, 96, 96, channels])
            b_imgs_384_p = b_imgs_384.reshape([batch_size, 384, 384, channels])
            b_imgs_96_p = tl.prepro.threading_data(b_imgs_384_p, fn = downsample_fn)
            errI, _ = sess.run([idt_loss, g_optim], {t_image: b_imgs_low_p, t_target_image: b_imgs_384_p, t_bic_image:b_imgs_96_p})
            errM, errMr = sess.run([mse_loss,mse_loss_r], {t_image: b_imgs_low_p, t_target_image: b_imgs_384_p, t_bic_image: b_imgs_96_p})
            print("Epoch [%2d/%2d] %4d time: %4.4fs, mse: %.8f mse_r:%.8f idt: %.8f" % (epoch, n_epoch_init, n_iter, time.time() - step_time, errM, errMr, errI))
            total_mse_loss += errM
            total_idt_loss += errI
            total_mse_r += errMr
            n_iter += 1
        log = "[*] Epoch: [%2d/%2d] time: %4.4fs, mse: %.8f , mse_r: %.8f idt:%.8f" % (epoch, n_epoch_init, time.time() - epoch_time, total_mse_loss / n_iter, total_mse_r/n_iter, total_idt_loss/n_iter)
        print(log)
        mse_total.append(total_mse_loss/n_iter)
        np.savetxt(save_dir_ginit + '/mse.txt', mse_total)
        mser_total.append(total_mse_r/n_iter)
        np.savetxt(save_dir_ginit + '/mser.txt', mser_total)
        idt_total.append(total_idt_loss/n_iter)
        np.savetxt(save_dir_ginit + '/idt.txt', idt_total)

        ## quick evaluation on test set
        if (epoch % 10 == 0):
            test_psnr = []
            test_ssim = []
            for i in range(len(test_lr_imgs)):
                test_hr = test_hr_imgs[i]
                test_lr = test_lr_imgs[i]
                size_lr = test_lr.shape
                size_hr = test_hr.shape
                # for gary image, channels shape set 1
                if len(size_lr) == 2:
                    size_lr.append(1)
                if len(size_hr) == 2:
                    size_hr.append(1)
                test_lr_batch = test_lr.reshape([size_lr[0], size_lr[1], size_lr[2]])
                out = cycle_network_test(size_lr[0], size_lr[1], size_lr[2], test_lr_batch, sess)
                out_image = out[0]
                psnr = cal_ypsnr(out_image, test_hr)
                print(psnr)
                ssim = compute_ssim(out_image, test_hr)
                print(ssim)
                tl.vis.save_image(out_image, save_dir_ginit + '/train_%d_%d_scale4.png' % (epoch, i))
                test_psnr.append(psnr)
                test_ssim.append(ssim)

            total_psnr.append(np.mean(test_psnr))
            total_ssim.append(np.mean(test_ssim))
            np.savetxt(save_dir_ginit + '/psnr.txt', total_psnr)
            np.savetxt(save_dir_ginit + '/ssim.txt', total_ssim)

        ## save model
        if (epoch != 0) and (epoch % 10 == 0):
            save_name = checkpoint_dir + '/g1_{}_init_' + ('%d' % epoch) + '.npz'
            tl.files.save_npz(net_g1.all_params, name=save_name.format(tl.global_flag['mode']), sess=sess)
            save_name = checkpoint_dir + '/g2_{}_init_' + ('%d' % epoch) + '.npz'
            tl.files.save_npz(net_g2.all_params, name=save_name.format(tl.global_flag['mode']), sess=sess)

if __name__ == '__main__':

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', type=str, default='cycle_cnn', help='cycle_cnn')
    args = parser.parse_args()

    tl.global_flag['mode'] = args.mode
    train()

